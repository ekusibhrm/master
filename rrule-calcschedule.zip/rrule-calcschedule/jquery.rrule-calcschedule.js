;(function($) {
    $.fn.rrule_calcschedule = function(id) {
        init(id);
        
        $('.rrule-freq').change(function() { //周期の変更による画面切り替え
            displaySwitching('freq', $(this), $(this).val());
        });
        $('.rrule-radio-until').change(function() { //終了日ラジオボタンの変更による画面切り替え
            displaySwitching('rrule-radio-until', $(this), $(this).val());
        });
        $('.rrule-radio-bycustom-month').change(function() { //日にちの指定ラジオボタンの変更による画面切り替え
            displaySwitching('rrule-radio-bycustom-month', $(this), $(this).val());
        });
        $('.rrule-radio-bycustom-year').change(function() { //月のラジオボタンの変更による画面切り替え
            displaySwitching('rrule-radio-bycustom-year', $(this), $(this).val());
        });
        $('.rrule-byday').change(function() { //曜日ラジオボタンの変更によるフォーム切り替え
            displaySwitching('rrule-byday', $(this));
        });
        $('.rrule-bymonth').change(function() { //月指定ラジオボタンの変更によるフォーム切り替え
            displaySwitching('rrule-bymonth', $(this));
        });
        $('.rrule-interval').focus(function() { //間隔にフォーカスが当たった場合、下線を引く
            removeUnderLine('freq');
            addUnderLine('.span-rrule-interval', 'freq');
        });
        $('.rrule-interval').blur(function() { //間隔からフォーカスが外れた場合、下線を消す
            removeUnderLine('freq');
        }); 
        $('.parent-rrule-checkbox').hover(
            function() { //チェックボックスにポインタが重なった場合、クラスを付与
                if(!$(this).find('input[type="checkbox"]').prop('checked')){
                    $(this).find('label').addClass('rrule-hover');
                    $(this).addClass('rrule-hover');
                }
            },
            function() { //チェックボックスからポインタが外れた場合、クラスを除去
                $(this).find('label').removeClass('rrule-hover');
                $(this).removeClass('rrule-hover');
            }
        );
        $('.parent-rrule-checkbox').find('label').hover(
            function() { //チェックボックスにポインタが重なった場合、クラスを付与
                if(!$(this).find('input[type="checkbox"]').prop('checked')){
                    $(this).addClass('rrule-hover');
                    $(this).closest('span').addClass('rrule-hover');
                }
            },
            function() { //チェックボックスからポインタが外れた場合、クラスを除去
                $(this).removeClass('rrule-hover');
                $(this).closest('span').removeClass('rrule-hover');
            }
        );
        $('.parent-rrule-checkbox').click(function(){ //ラジオボタンの親要素クリック時にも反応するように
            displaySwitching('parent-rrule-checkbox', $(this));
        });
        
        requiredCheck();
        $('.rrule-btn-enter').click(function () { // 完了
            var val_arr = getAllFormValue(); //フォームの値からRRULEのルールに則って値を取得
            
            if(!errorCheck(val_arr)){ //必須項目が未入力または正しい値でない場合、falseを返却
                return false;
            }
            /** 項目がすべて正しく入力されていたら日付計算処理 **/
            var rruleStr = conversionRruleString(val_arr); //RRULEの書式に変換
            var rrule = rruleFromString(rruleStr);
            
            /** スケジュールを日本語化 **/
            var rrule_jp = rruleConversionToJapanese(val_arr);
            
            /** クラスがあればRRULE書式を格納 **/
            var input_tagname = $(".rrule-string-input[data-rruleid='"+id+"']").prop('tagName');
            var hidden_tagname = $(".rrule-string-hidden[data-rruleid='"+id+"']").prop('tagName');
            if(input_tagname == 'INPUT') {
                $(".rrule-string-input[data-rruleid='"+id+"']").val(rrule_jp);
            } else if(input_tagname == 'DIV' || input_tagname == 'SPAN' || input_tagname == 'P') {
                $(".rrule-string-input[data-rruleid='"+id+"']").html(rrule_jp);
            }
            if(hidden_tagname == 'INPUT') {
                $(".rrule-string-hidden[data-rruleid='"+id+"']").val(rruleStr);
            } else if(hidden_tagname == 'DIV' || hidden_tagname == 'SPAN' || hidden_tagname == 'P') {
                $(".rrule-string-hidden[data-rruleid='"+id+"']").html(rruleStr);
            }
            
            /** クラスがあれば日付を表示、格納 **/
            var first_date_class = $('body').find('.rrule-first-date[data-rruleid="'+id+'"]'); //次回実行日
            var second_date_class = $('body').find('.rrule-second-date[data-rruleid="'+id+'"]'); //2回目
            var third_date_class = $('body').find('.rrule-third-date[data-rruleid="'+id+'"]'); //3回目
            var all_date_class = $('body').find('.rrule-all-date[data-rruleid="'+id+'"]'); //hiddenのvalue値にjsonですべて渡す
            if(first_date_class.length !== 0){
                var first_tagName = first_date_class.prop('tagName');
                if(first_tagName == 'INPUT') {
                    if(rrule[0]){
                        first_date_class.val(rrule[0]);
                    }else{
                        first_date_class.val("");
                    }
                } else if(first_tagName == 'DIV' || first_tagName == 'SPAN' || first_tagName == 'P') {
                    first_date_class.html("");
                    if(rrule[0]){
                        first_date_class.html(rrule[0]);
                    }else{
                        first_date_class.html("なし");
                    }
                }
            }
            if(second_date_class.length !== 0){
                var second_tagName = second_date_class.prop('tagName');
                if(second_tagName == 'INPUT') {
                    if(rrule[1]){
                        second_date_class.val(rrule[1]);
                    }else{
                        second_date_class.val("");
                    }
                } else if(second_tagName == 'DIV' || second_tagName == 'SPAN' || second_tagName == 'P') {
                    second_date_class.html("");
                    if(rrule[1]){
                        second_date_class.html(rrule[1]);
                    }else{
                        second_date_class.html("なし");
                    }
                }
            }
            if(third_date_class.length !== 0){
                var third_tagName = third_date_class.prop('tagName');
                if(third_tagName == 'INPUT') {
                    if(rrule[2]){
                        third_date_class.val(rrule[2]);
                    }else{
                        third_date_class.val("");
                    }
                } else if(third_tagName == 'DIV' || third_tagName == 'SPAN' || third_tagName == 'P') {
                    third_date_class.html("");
                    if(rrule[2]){
                        third_date_class.html(rrule[2]);
                    }else{
                        third_date_class.html("なし");
                    }
                }
            }
            if(all_date_class.length !== 0){
                var json = "";
                var all_tagName = all_date_class.prop('tagName');
                if(all_tagName == 'INPUT' || all_tagName == 'TEXTAREA') {
                    if(rrule){
                        json = conversionJson(rrule);
                        all_date_class.val("");
                        all_date_class.val(json);
                    }else{
                        all_date_class.val("");
                    }
                } else if(third_tagName == 'DIV' || third_tagName == 'SPAN' || third_tagName == 'P') {
                    if(rrule){
                        json = conversionJson(rrule);
                        all_date_class.html(json);
                    }else{
                        all_date_class.html("なし");
                    }
                }
            }
            modalClose();
        });

        $('.rrule-btn-cancel').click(function () { // キャンセル
            modalClose();
        });
    }
})(jQuery);

$(function() {
    $('.rrule-string-input').focus(function(){
        var id = $(this).data("rruleid");
        modalOpen(id);
        $('.rrule-string-input').rrule_calcschedule(id);
    });
});
/**
 * 初期化
 */
function init(id) {
    const form_value = $('.rrule-string-hidden[data-rruleid="'+id+'"]').val();
    if(form_value){
        var form_arr = form_value.split(";");
        var val_arr = new Array();

        for(var val of form_arr){
            var val_sp = val.split("=");
            val_arr[val_sp[0]] = val_sp[1];
        }
        /** 周期の初期値設定 **/
        if(val_arr['FREQ']){
            $('.rrule-freq').val(val_arr['FREQ']);
        }
        /** 間隔の初期値設定 **/
        if(val_arr['INTERVAL']){
            $('.rrule-interval').val(val_arr['INTERVAL']);
        }
        /** 開始日時の初期値設定 **/
        if(val_arr['DTSTART']){
            var dtstart_date = reverseFormatISO8601OnlyDate(val_arr['DTSTART']);
            var dtstart_time = reverseFormatISO8601OnlyTime(val_arr['DTSTART']);
            $('.rrule-dtstart-date').val(dtstart_date);
            $('.rrule-dtstart-time').val(dtstart_time);
        }
        /** 終了日時の初期値設定 **/
        if(val_arr['UNTIL']){
            var until_date = reverseFormatISO8601OnlyDate(val_arr['UNTIL']);
            var until_time = reverseFormatISO8601OnlyTime(val_arr['UNTIL']);
            $('.rrule-until-date').val(until_date);
            $('.rrule-until-time').val(until_time);
            $('.rrule-radio-until[value="1"]').prop('checked', true);
            $('.div-rrule-until').show();
            removeUnderLine('until');
            addUnderLine('.div-rrule-until', 'until');
        }
        /** 回数の初期設定 **/
        if(val_arr['COUNT']){
            $('.rrule-count').val(val_arr['COUNT']);
            $('.rrule-radio-until[value="2"]').prop('checked', true);
            $('.div-rrule-count').show();
            removeUnderLine('until');
            addUnderLine('.div-rrule-count', 'until');
        }
        /** 年ごとの月指定の初期値設定 **/
        if(val_arr['BYMONTH']){
            var checked_month = val_arr['BYMONTH'].split(',');
            for(var month of checked_month){
                $('.rrule-bymonth[value="'+month+'"]').prop('checked', true);
                $('.rrule-bymonth[value="'+month+'"]').closest('span').addClass('rrule-checked');
            }
            $('.rrule-radio-bycustom-year[value="1"]').prop('checked', true);
            $('.div-rrule-bymonth').show();
        }
        /** 月ごとの日にち指定の初期値設定 **/
        if(val_arr['BYMONTHDAY']){
            if(val_arr['BYMONTHDAY'] == "-1"){
                $('.rrule-radio-bycustom-month[value="2"]').prop('checked', true);
            }else{
                $('.rrule-bymonthday').val(val_arr['BYMONTHDAY']);
                $('.div-rrule-bymonthday').show();
            }
        } else if(val_arr['BYDAY'] && val_arr['BYSETPOS']) {
            if(val_arr['BYSETPOS'] == "-1"){
                $('.rrule-bysetpos-weekday-number').val('5');
            } else {
                $('.rrule-bysetpos-weekday-number').val(val_arr['BYSETPOS']);
            }
            $('.rrule-bysetpos-weekday-item').val(val_arr['BYDAY']);
            $('.rrule-radio-bycustom-month[value="1"]').prop('checked', true);
            $('.div-rrule-bymonthday').hide();
            $('.div-rrule-bysetpos-weekday').show();
        }
        /** 週ごとの曜日指定の初期値設定 **/
        if(val_arr['BYDAY'] && !val_arr['BYSETPOS']) {
            var checked_weekday = val_arr['BYDAY'].split(',');
            for(var weekday of checked_weekday){
                $('.rrule-byday[value="'+weekday+'"]').prop('checked', true);
                $('.rrule-byday[value="'+weekday+'"]').closest('span').addClass('rrule-checked');
            }
        }
    }
    else{
        var now = new Date();
        const year = now.getFullYear();
        const month = ('00' + (now.getMonth() + 1)).substr(-2);
        const day = ('00' + now.getDate()).substr(-2);
        const hour = ('00' + now.getHours()).substr(-2);
        const minute = ('00' + now.getMinutes()).substr(-2);
        $('.rrule-dtstart-date').val(year+"-"+month+"-"+day);
        $('.rrule-dtstart-time').val(hour+":"+minute);
    }
    displaySwitching('init', null, $('.rrule-freq').val());
    displaySwitching('rrule-radio-until', null, $('.rrule-radio-until:checked').val());
    return true;
}
/**
 * 値を取得
 * @returns array
 */
function getAllFormValue() {
        var freq = "";  //周期
        var interval = ""; //間隔
        var dtstart = ""; //開始日
        var until = ""; //終了日
        var count = ""; //回数
        var wkst = ""; //週の始まりの曜日
        var byday = ""; //曜日の指定
        var bymonth = ""; //月の指定(1~12)
        var bysetpos = ""; //日にちの指定(1 ~ 366 or -366 ~ -1) ⇒byday,bymonthと組み合わせで最終日曜日等を取得
        var bymonthday = ""; //月の日の指定(1 ~ 31 or -31 ~ -1) ⇒月末、月初、何日を取得
//        var byyearday = ""; //年の日の指定(1 ~ 366 or -366 ~ -1)⇒年末、年始を取得
//        var byweekno = ""; //年の週の指定(1 ~ 53 or -53 ~ -1)
//        var byhour = $('.rrule-byhour').val();　//日の時間の指定(0 ~ 23)
//        var byminute = $('.rrule-byminute').val(); //時間の分の指定(0 ~ 59)
//        var bysecond = $('.rrule-bysecond').val(); //分の秒の指定 (0 ~ 59)
        
        /** 周期、間隔は必須(間隔はデフォルト1) **/
        freq = $('.rrule-freq').val(); //周期
        interval = $('.rrule-interval').val(); //間隔
        
        /** 開始日(未入力なら現在日付) **/
        if($('.rrule-dtstart-date').val() && $('.rrule-dtstart-time').val()){
            dtstart = $('.rrule-dtstart-date').val() + " " + $('.rrule-dtstart-time').val();
        }
        dtstart = dtstart ? conversionFormatISO8601Basic(new Date(dtstart)) : conversionFormatISO8601Basic(new Date()); //開始日時(ISO8601 基本形式)
        
        /** 終了日と回数は一方のみ指定できる **/
        if($('.rrule-radio-until:checked').val() == "1") {
            if($('.rrule-until-date').val() && $('.rrule-until-time').val()){
                until = $('.rrule-until-date').val() + " " + $('.rrule-until-time').val();
            }
            until = until ? conversionFormatISO8601Basic(new Date(until)): ""; //終了日時(ISO8601 基本形式)
        } else if ($('.rrule-radio-until:checked').val() == "2") {
            count = $('.rrule-count').val(); //回数
        }
        
        /** デフォルトは月曜日始まり **/
        wkst = "MO"; //週の始まりの曜日
//        wkst = $('.rrule-wkst').val(); //週の始まりの曜日
        
        
        var bycustom = getCustomvalue(freq); //カスタム値(by****)を取得
        byday = bycustom['byday'];
        bymonth = bycustom['bymonth'];;
        bysetpos = bycustom['bysetpos'];
        bymonthday = bycustom['bymonthday'];
//        byyearday = bycustom['byyearday'];
//        byweekno = bycustom['byweekno'];
//        byhour = bycustom['byhour'];
//        byminute = bycustom['byminute'];
//        bysecond = bycustom['bysecond'];
        
        return {
                'freq' : freq,
                'interval' : interval,
                'dtstart' : dtstart,
                'until' : until,
                'count' : count,
                'wkst' : wkst,
                'byday' : byday,
                'bymonth' : bymonth,
                'bysetpos' : bysetpos,
                'bymonthday' : bymonthday,
//                'byyearday' : byyearday,
//                'byweekno' : byweekno,
//                'byhour' : byhour,
//                'byminute' : byminute,
//                'byhour' : byhour,
            };
}

/**
 * パラメータをRRULE書式に変換し、返却
 * @param array 結果
 * @returns String RRULE書式
 */
function conversionRruleString(arr) {
        var rruleStr = "";
        
        if(arr['freq']){
            rruleStr += "FREQ=" + arr['freq'] + ";";
        }
        if(arr['dtstart']){
            rruleStr += "DTSTART=" + arr['dtstart'] + ";";
        }
        if(arr['until']){
            rruleStr += "UNTIL=" + arr['until'] + ";";
        }
        if(arr['count']){
            rruleStr += "COUNT=" + arr['count'] + ";";
        }
        if(arr['interval']){
            rruleStr += "INTERVAL=" + arr['interval'] + ";";
        }
        if(arr['wkst']){
            rruleStr += "WKST=" + arr['wkst'] + ";";
        }
        if(arr['byday']){
            rruleStr += "BYDAY=" + arr['byday'] + ";";
        }
        if(arr['bymonth']){
            rruleStr += "BYMONTH=" + arr['bymonth'] + ";";
        }
        if(arr['bysetpos']){
            rruleStr += "BYSETPOS=" + arr['bysetpos'] + ";";
        }
        if(arr['bymonthday']){
            rruleStr += "BYMONTHDAY=" + arr['bymonthday'] + ";";
        }
//        if(arr['byyearday']){
//            rruleStr += "BYYEARDAY=" + arr['byyearday'] + ";";
//        }
//        if(arr['byweekno']){
//            rruleStr += "BYWEEKNO=" + arr['byweekno'] + ";";
//        }
//        if(arr['byhour']){
//            rruleStr += "BYHOUR=" + arr['byhour'] + ";";
//        }
//        if(arr['byminute']){
//            rruleStr += "BYMINUTE=" + arr['byminute'] + ";";
//        }
//        if(arr['bysecond']){
//            rruleStr += "BYSECOND=" + arr['bysecond'] + ";";
//        }
        rruleStr = rruleStr.substr(-1, 1) == ";" ?  rruleStr.slice(0, -1) : rruleStr; //末尾が";"の場合末尾削除
        return rruleStr;
}

/**
 * 画面切り替え
 * @param type item
 * @param type val
 * @returns Boolean
 */
function displaySwitching(item, element, val = null) {
    
    if(item == 'init'|| item == 'freq'){ //初期状態または周期の変更による
        switch(val) {
            case 'YEARLY':
                $('.rrule-modal').css('height', '290px');
                $('.tbl-bymonth').show();
                $('.tbl-bysetpos').hide();
                $('.tbl-byday').hide();
                removeUnderLine('bysetpos');
                break;
            case 'MONTHLY':
                $('.rrule-modal').css('height', '290px');
                $('.tbl-bysetpos').show();
                $('.tbl-bymonth').hide();
                $('.tbl-byday').hide();
                displaySwitching('rrule-radio-bycustom-month', null, $('.rrule-radio-bycustom-month:checked').val());
                break;
            case 'WEEKLY':
                $('.rrule-modal').css('height', '230px');
                $('.tbl-byday').show();
                $('.tbl-bymonth').hide();
                $('.tbl-bysetpos').hide();
                removeUnderLine('bysetpos');
                break;
            default:
                $('.rrule-modal').css('height', '200px');
                $('.tbl-bymonth').hide();
                $('.tbl-bysetpos').hide();
                $('.tbl-byday').hide();
                removeUnderLine('bysetpos');
                break;
                
        }
        return true;
    }
    
    if(item == 'rrule-radio-until') { //終了日のラジオボタンの変更による
        switch(val) {
            case '1': //終了日を設定
                $('.div-rrule-until').show();
                $('.div-rrule-count').hide();
                removeUnderLine('until');
                addUnderLine('.div-rrule-until', 'until');
                break;
            case '2': //回数を設定
                $('.div-rrule-until').hide();
                $('.div-rrule-count').show();
                
                var tmp_val = $('.rrule-count').val();
                $('.rrule-count').val('');
                $('.rrule-count').focus();
                $('.rrule-count').val(tmp_val);
                $('.rrule-count').focus(); //フォーカスを入力欄に合わせる
                removeUnderLine('until');
                addUnderLine('.div-rrule-count', 'until');
                break;
            default:
                $('.div-rrule-until').hide();
                $('.div-rrule-count').hide();
                removeUnderLine('until');
                break;
                
        }
        return true;
    }
    
    if(item == 'rrule-radio-bycustom-month') { //日にちの指定のラジオボタンの変更による
        switch(val) {
            case '0': //日にち指定
                $('.div-rrule-bymonthday').show();
                $('.div-rrule-bysetpos-weekday').hide();
                var tmp_val = $('.rrule-bymonthday').val();
                $('.rrule-bymonthday').val('');
                $('.rrule-bymonthday').focus();
                $('.rrule-bymonthday').val(tmp_val);
                $('.rrule-bymonthday').focus(); //フォーカスを入力欄に合わせる
                removeUnderLine('bysetpos');
                addUnderLine('.div-rrule-bymonthday', 'bysetpos');
                break;
            case '1': //曜日指定
                $('.div-rrule-bymonthday').hide();
                $('.div-rrule-bysetpos-weekday').show();
                removeUnderLine('bysetpos');
                addUnderLine('.div-rrule-bysetpos-weekday', 'bysetpos');
                break;
            case '2': //月末
                $('.div-rrule-bymonthday').hide();
                $('.div-rrule-bysetpos-weekday').hide();
                $('.rrule-checkbox-style-after').remove();
                removeUnderLine('bysetpos');
                break;
        }
        return true;
    }
    
    if(item == 'rrule-radio-bycustom-year') { //月の指定のラジオボタンの変更による
        switch(val) {
            case '1': //月指定
                $('.div-rrule-bymonth').show();;
                break;
            default:
                $('.div-rrule-bymonth').hide();
                break;
        }
        return true;
    }
    if(item == 'parent-rrule-checkbox') {
        var checked = element.find('input[type=checkbox]').prop("checked");
        if(checked){
            element.find('input[type=checkbox]').prop("checked",false);
            element.closest('span').removeClass('rrule-checked');
        }else{
            element.find('input[type=checkbox]').prop("checked",true);
            element.closest('span').addClass('rrule-checked');
        }
        element.closest('span').removeClass('rrule-hover');
        element.find('rrule-hover').removeClass('rrule-hover');
        element.removeClass('rrule-hover');
        return true;
    }
}

/**
 * 日付をISO8601基本表記に変換し、返却
 * @param type date
 * @returns String　日付(yyyyMMDD + "T" + HHmmss)
 */
function conversionFormatISO8601Basic(date) {
    const year = date.getFullYear();
    const month = ('00' + (date.getMonth() + 1)).substr(-2);
    const day = ('00' + date.getDate()).substr(-2);
    const hour = ('00' + date.getHours()).substr(-2);
    const minute = ('00' + date.getMinutes()).substr(-2);
    const second = '00';
//    const second = ('00' + date.getSeconds()).substr(-2);
    
    return year + month + day + 'T' + hour + minute + second;
}
/**
 * 日付を ISO8601基本表記から yyyy/MM/dd HH:mm に変換し、返却
 * @param String
 * @returns String　日付(yyyy/MM/dd HH:mm)
 */
function reverseFormatISO8601Basic(date) {
    const year = date.substr(0,4);
    const month = date.substr(4,2);
    const day = date.substr(6,2);
    const hour = date.substr(-6,2);
    const minute = date.substr(-4,2);
    
    return year + "/" + month + "/" + day + ' ' + hour + ":" + minute;
}

/**
 * 日付をISO8601拡張表記に変換し、返却
 * @param type date
 * @returns String　日付(yyyy/MM/DD + "T" + HH:mm)
 */
function conversionFormatISO8601Extension(date) {
    const tz_diff = 9; //UTCと比較した時差
    const shift = date.getTime()+60*60*1000*tz_diff;
    const time = new Date(shift).toISOString().split('.')[0].slice(0,-3);
    return time;
}
/**
 * ISO8601基本表記から日付のみを yyyy-MM-dd に変換し、返却
 * @param String
 * @returns String　日付(yyyy-MM-DD)
 */
function reverseFormatISO8601OnlyDate(datetime) {
    var date = datetime.split('T')[0];
    const year = date.substr(0,4);
    const month = date.substr(4,2);
    const day = date.substr(6,2);
    
    date = year + "-" + month + "-" + day;
    return date;
}
/**
 * ISO8601基本表記から時間のみを HH:mm に変換し、返却
 * @param String
 * @returns String　時間(HH:mm)
 */
function reverseFormatISO8601OnlyTime(datetime) {
    var time = datetime.split('T')[1];
    const hour = time.substr(0,2);
    const minute = time.substr(2,2);
//    const second = time.substr(4,2);
    
    time = hour + ":" + minute;
    return time;
}
/**
 * 入力値から
 * カスタム値（by****)を
 * 組み合わせて返却 
 * (周期によって使用できるカスタム値が異なる)
 * 
 * @param type freq/周期
 * @returns array カスタム値
 */
function getCustomvalue(freq){
    
    var byday = "";
    var bymonth = "";
    var bysetpos = "";
    var byyearday = "";
    var bymonthday = "";
    var byhour = "";
    var byminute = "";
    var bysecond = "";
    var byweekno = "";
    
    if(freq == "WEEKLY") {  //周期が週ごとの場合
        /** 対象曜日の指定（複数選択可 ※カンマ区切り） **/
        var byday_arr = new Array();
        $('[class="rrule-byday"]:checked').each(function(){
            byday_arr.push($(this).val());
        });
        byday = byday_arr.join(","); //対象の曜日(カンマ区切り)
    }

    else if(freq == "YEARLY") {  //周期が年ごとの場合
        var custom_flag = $('.rrule-radio-bycustom-year:checked').val();
        switch(custom_flag) {
            case '1':
                /** 対象月の指定（複数選択可 ※カンマ区切り） **/
                var bymonth_arr = new Array();
                $('[class="rrule-bymonth"]:checked').each(function(){
                    bymonth_arr.push($(this).val());
                });
                bymonth = bymonth_arr.join(","); //対象の月(カンマ区切り)
                break;
            default:
                break;
        }
    }
    
    else if(freq == "MONTHLY") { //周期が月ごとの場合
        var custom_flag = $('.rrule-radio-bycustom-month:checked').val();
        switch(custom_flag) {
            case '0':
                /** 対象日の指定 **/
                bymonthday = $('.tbl-rrule-bycustom-month').find('.rrule-bymonthday').val(); //**日
                break;
            case '1':
                bysetpos = $('.tbl-rrule-bycustom-month').find('.rrule-bysetpos-weekday-number').val(); //第**
                bysetpos = bysetpos == "5" ? "-1" : bysetpos; //最終の曜日のためbysetposは-1
                byday = $('.tbl-rrule-bycustom-month').find('.rrule-bysetpos-weekday-item').val(); //**曜日
                break;
            case '2':
                bymonthday = "-1"; //月末
                break;
        }
    }
            
    return {
        'byday' : byday,
        'bymonth' : bymonth,
        'bysetpos' : bysetpos,
        'byyearday' : byyearday,
        'bymonthday' : bymonthday,
        'byhour' : byhour,
        'byminute' : byminute,
        'bysecond' : bysecond,
        'byweekno' : byweekno
    };
}

/**
 * スケジュールモーダルOPEN
 */
function modalOpen(id){
    var modalTemplate = `
      <div class="rrule-modal">
        <form>
          <table>

            <tbody>
              <tr class="tbl-freq">
                <th>
                  <div class="option-name"><span>間隔:</span></div>
                </th>
                <td>
                  <span class="span-rrule-interval">
                    <input type="number" value="1" min="1" name="interval" class="rrule-interval" />
                  </span>
                  <select name="freq" class="rrule-freq">
                    <option value="YEARLY">年ごと</option>
                    <option value="MONTHLY">か月ごと</option>
                    <option value="WEEKLY" selected>週間ごと</option>
                    <option value="DAILY">日ごと</option>
                    <option value="HOURLY">時間ごと</option>
                    <option value="MINUTELY">分ごと</option>
                        <!--<option value="SECONDLY">秒ごと</option>-->
                  </select>
                </td>
              </tr>
              <tr class="tbl-dtstart">
                <th>
                  <div class="option-name"><span>開始日時:</span></div>
                </th>
                <td>
                  <input name="dtstart-date" type="date" class="rrule-dtstart-date"/>
                  <input name="dtstart-time" type="time" class="rrule-dtstart-time" value="00:00"/>
                </td>
              </tr>
              <tr class="tbl-bysetpos" style="display:none">
                <th>
                  <div class="option-name"><span>日にち:</span></div>
                </th>
                <td class="tbl-rrule-bycustom-month">
                  <div>
                  <label>
                    <input type="radio" value="0" name="rrule-radio-bycustom-month" class="rrule-radio-bycustom-month" checked/>日付指定</label>
                    <div class="div-rrule-bymonthday">毎月<input type="number" value="1" min="1" max="28" class="rrule-bymonthday" />日</div>
                  </div>
                  <div>
                  <label>
                    <input type="radio" value="1" name="rrule-radio-bycustom-month" class="rrule-radio-bycustom-month"/>曜日指定</label>
                    <div class="div-rrule-bysetpos-weekday" style="display:none">
                        <select  name="bysetpos" class="rrule-bysetpos-weekday-number">
                          <option value="1" selected>第1</option>
                          <option value="2">第2</option>
                          <option value="3">第3</option>
                          <option value="4">第4</option>
                          <option value="5">最終</option>
                        </select>
                        <select name="bysetpos" class="rrule-bysetpos-weekday-item">
                          <option value="MO" selected>月曜日</option>
                          <option value="TU">火曜日</option>
                          <option value="WE">水曜日</option>
                          <option value="TH">木曜日</option>
                          <option value="FR">金曜日</option>
                          <option value="SA">土曜日</option>
                          <option value="SU">日曜日</option>
                        </select>
                    </div>
                  </div>
                  <div>
                  <label>
                    <input type="radio" value="2" name="rrule-radio-bycustom-month" class="rrule-radio-bycustom-month" />月末</label>
                  </div>
                </td>
              </tr>
              <tr class="tbl-bymonth" style="display:none">
                <th>
                  <div class="option-name"><span>月:</span></div>
                </th>
                <td class="tbl-rrule-bycustom-year">
                  <div>
                  <label>
                    <input type="radio" value="0" name="rrule-radio-bycustom-year" class="rrule-radio-bycustom-year" checked/>なし</label>
                  </div>
                  <div>
                  <label>
                    <input type="radio" value="1" name="rrule-radio-bycustom-year" class="rrule-radio-bycustom-year" />月指定</label>
                  </div>
                  <div class="div-rrule-bymonth" style="display:none">
                      <div class="rrule-month-first-block">
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="1" />1</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="2" />2</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="3" />3</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="4" />4</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="5" />5</label>
                        </span>
                        <span class="parent-rrule-checkbox parent-rrule-last">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="6" />6</label>
                        </span>
                      </div>
                      <div class="rrule-month-second-block">
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="7" />7</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="8" />8</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="9" />9</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="10" />10</label>
                        </span>
                        <span class="parent-rrule-checkbox">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="11" />11</label>
                        </span>
                        <span class="parent-rrule-checkbox parent-rrule-last">
                        <label>
                          <input name="bymonth" type="checkbox" class="rrule-bymonth" value="12" />12</label>
                        </span>
                      </div>
                  </div>
                </td>
              </tr>
              <tr class="tbl-byday" style="display:none">
                <th>
                  <div class="option-name"><span>曜日:</span></div>
                </th>
                <td>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="MO">月</label>
                  </span>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="TU">火</label>
                  </span>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="WE">水</label>
                  </span>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="TH">木</label>
                  </span>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="FR">金</label>
                  </span>
                  <span class="parent-rrule-checkbox">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="SA">土</label>
                  </span>
                  <span class="parent-rrule-checkbox parent-rrule-last">
                  <label>
                    <input type="checkbox" name="byweekday" class="rrule-byday" value="SU">日</label>
                  </span>
                </td>
              </tr>
              <tr class="tbl-until">
                <th>
                  <div class="option-name"><span>終了日時:</span></div>
                </th>
                <td>
                  <div>
                  <label>
                    <input type="radio" value="1" name="rrule-radio-until" class="rrule-radio-until" checked/>終了日時を設定</label>
                  </div>
                  <div class="div-rrule-until" style="display:none">
                    <input name="until-date" type="date" class="rrule-until-date"/>
                    <input name="until-time" type="time" class="rrule-until-time" value="00:00"/>
                  </div>
                  <div>
                  <label>
                    <input type="radio" value="2" name="rrule-radio-until" class="rrule-radio-until" />回数を設定</label>
                  </div>
                  <div class="div-rrule-count" style="display:none">
                    <input type="number" max="1000" min="1" value="5" name="count" class="rrule-count"/>回
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
        <div class="rrule-exe-btn-area">
            <span class="rrule-btn-cancel">キャンセル</span>
            <span class="rrule-btn-enter">完了</span>
        </div>
        `;
    
    $('.rrule-string-input[data-rruleid="'+id+'"]').after(modalTemplate);
    let w = $(window).width();
    let h = $(window).innerHeight();
    
    let cw = $('.rrule-modal').outerWidth();
    let ch = $('.rrule-modal').outerHeight();
   
    $('.rrule-modal').css({
      'left': ((w - cw) / 2) + 'px',
      'top': ((h - ch) / 2) + 'px'
    });
    if($('.rrule-calcschedule-overlay')[0]){ // すでにオーバーレイが存在していたら何もしない
        return false;
    }
    $('body').append('<div class="rrule-calcschedule-overlay"></div>'); // オーバーレイをセット
    $('.rrule-calcschedule-overlay').fadeIn(300);
    $('.rrule-samural-modal').fadeIn(400);
    // オーバーレイとモーダルをaddでまとめてフェードアウト後モーダル自身を削除
    $('.rrule-calcschedule-overlay').add($('#js_modal_close')).on('click', function(){
        modalClose();
    });
};

/**
 * スケジュールモーダルCLOSE
 */
function modalClose(){
    $('.rrule-calcschedule-modal').add($('.rrule-calcschedule-overlay')).fadeOut(300, function(){
        $('.rrule-calcschedule-overlay').remove();
        $('.rrule-modal').remove();
    });
}

/**
 * 下線を引く処理
 */
function addUnderLine(target, tbl){
    switch(tbl){
        case 'freq':
            $(target).addClass('rrule-underline-interval');
            var style = '<style type="text/css" class="rrule-underline-interval-before"></style>';
            $('head').append(style);
            var cssTemplate = '<style type="text/css" class="rrule-underline-interval-after">.rrule-underline-interval::before,.rrule-underline-interval::after{width: 50%;}</style>';                

            setTimeout( function(){
            $('.rrule-underline-interval-before').replaceWith($(cssTemplate));
            }, 100);
            break;
        case 'bysetpos':
            $(target).addClass('rrule-underline-bysetpos');
            var style = '<style type="text/css" class="rrule-underline-bysetpos-before"></style>';
            $('head').append(style);
            var cssTemplate = '<style type="text/css" class="rrule-underline-bysetpos-after">.rrule-underline-bysetpos::before,.rrule-underline-bysetpos::after{width: 50%;}</style>';                

            setTimeout( function(){
            $('.rrule-underline-bysetpos-before').replaceWith($(cssTemplate));
            }, 100);
            break;
        case 'until':
            $(target).addClass('rrule-underline-until');
            var style = '<style type="text/css" class="rrule-underline-until-before"></style>';
            $('head').append(style);
            var cssTemplate = '<style type="text/css" class="rrule-underline-until-after">.rrule-underline-until::before,.rrule-underline-until::after{width: 50%;}</style>';                

            setTimeout( function(){
            $('.rrule-underline-until-before').replaceWith($(cssTemplate));
            }, 100);
            break;
    }
    
    return true;
}
/**
 * 下線を消す処理
 */
function removeUnderLine(tbl){
    switch(tbl){
        case 'freq':
            $('.rrule-underline-interval-after').remove();
            $('.tbl-'+tbl).find('.rrule-underline-interval').removeClass('rrule-underline-interval');
            break;
        case 'bysetpos':
            $('.rrule-underline-bysetpos-after').remove();
            $('.tbl-'+tbl).find('.rrule-underline-bysetpos').removeClass('rrule-underline-bysetpos');
            break;
        case 'until':
            $('.rrule-underline-until-after').remove();
            $('.tbl-'+tbl).find('.rrule-underline-until').removeClass('rrule-underline-until');
            break;
    }
    return true;
}
/**
 * 次回日付を計算
 */
function rruleFromString(rruleStr){
    if(rruleStr){
        rruleStr = rruleStr.split(";");
        var rrule_arr = new Array();

        for(var rrule of rruleStr){
            var rrule_sp = rrule.split("=");
            rrule_arr[rrule_sp[0]] = rrule_sp[1];
        }
    } else {
        return false;
    }
    var freq = rrule_arr['FREQ'] ? rrule_arr['FREQ'] : "";
    var dtstart = rrule_arr['DTSTART'] ? rrule_arr['DTSTART'] : "";
    var interval = rrule_arr['INTERVAL'] ? parseInt(rrule_arr['INTERVAL']) : "";
    var wkst = rrule_arr['WKST'] ? rrule_arr['WKST'] : "";
    var until = rrule_arr['UNTIL'] ? rrule_arr['UNTIL'] : "";
    var count = rrule_arr['COUNT'] ? parseInt(rrule_arr['COUNT']) : "";
    var byday = freq == "WEEKLY" && rrule_arr['BYDAY'] ? rrule_arr['BYDAY'].split(",") : rrule_arr['BYDAY'] ? rrule_arr['BYDAY'] : "";
    var bymonth = rrule_arr['BYMONTH'] ? rrule_arr['BYMONTH'].split(",") : "";
    var bysetpos = rrule_arr['BYSETPOS'] ? rrule_arr['BYSETPOS'] : "";
    var bymonthday = rrule_arr['BYMONTHDAY'] ? rrule_arr['BYMONTHDAY'] : "";
    
    if(!freq || !dtstart || !interval || !wkst){ //必須チェック
        return false;
    }
    if(!until && !count){ //必須チェック
        return false;
    }
    var date_now = new Date();
    date_now = new Date(date_now.getFullYear(), date_now.getMonth(), date_now.getDate(), date_now.getHours(), date_now.getMinutes()); //秒を含めない
    var re_dtstart = new Date(reverseFormatISO8601Basic(dtstart));
    const date_const = new Date(re_dtstart.getFullYear(), re_dtstart.getMonth(), re_dtstart.getDate(), re_dtstart.getHours(), re_dtstart.getMinutes()); //比較することがあるため
    var date_var = new Date(re_dtstart.getFullYear(), re_dtstart.getMonth(), re_dtstart.getDate(), re_dtstart.getHours(), re_dtstart.getMinutes());
    var all_dates = new Array();
    if(count){ //終了回数指定
        for(var i=0; i < count; i++){
            all_dates = calcSchedule(freq, interval, byday, bymonth, bysetpos, bymonthday, date_now, date_const, date_var, all_dates, i);
            if(all_dates.length == 0){
                i--;
            }
        }
    }
    else { //終了日時指定
        var until_date = new Date(reverseFormatISO8601Basic(until));
        var end_schedule_flag = false;
        var i = 0;
        while(!end_schedule_flag){
            all_dates = calcSchedule(freq, interval, byday, bymonth, bysetpos, bymonthday, date_now, date_const, date_var, all_dates, i);          
            var last_date = new Date(all_dates[all_dates.length - 1]);
            while(all_dates.length !== 0  && (until_date < last_date)){
                all_dates.pop();
                end_schedule_flag = true;
                last_date = new Date(all_dates[all_dates.length - 1]);
            }
            i++;
        }
    }
    return all_dates; 
}

/**
 * スケジュール計算
 * @param {type} freq
 * @param {type} interval
 * @param {type} byday
 * @param {type} bymonth
 * @param {type} bysetpos
 * @param {type} bymonthday
 * @param {type} date_now
 * @param {type} date_const
 * @param {type} date_var
 * @param {type} all_dates
 * @param {type} loop
 * @returns {array}
 */
function calcSchedule(freq, interval, byday, bymonth, bysetpos, bymonthday, date_now, date_const, date_var, all_dates, loop){
    switch(freq){
        case 'YEARLY': //年ごと
            if(bymonth){ /***** 月指定 *****/
                var month_cnt = 0;
                if(loop == 0){ bymonth = bymonth.reverse(); }
                for(var month of bymonth){
                    var tmp_date = date_var.getDate();
                    date_var.setDate(1);
                    date_var.setMonth(month-1);
                    date_var.setDate(tmp_date);
                    if(loop == 0){
                        if(date_var < date_const) {
                            continue;
                        }
                    } else if(month_cnt == 0) {
                        date_var.setFullYear(date_var.getFullYear()+interval);
                    }
                    if(date_now.getTime() <= date_var.getTime()){
                        all_dates.push(formatDateString(date_var));
                    }
                    month_cnt++;
                }
                if(all_dates.length == 0){
                    date_var.setFullYear(date_var.getFullYear()+interval);
                    return all_dates;
                }
                if(loop == 0){
                    bymonth = bymonth.reverse();
                    all_dates.sort(function(a, b){
                        return (a > b ? 1 : -1);
                    });
                }
            }
            else{ /***** 月指定なし *****/
                if(date_var < date_now){
                    date_var.setFullYear(date_var.getFullYear()+interval);
                    return all_dates;
                }
                all_dates.push(formatDateString(date_var));
                date_var.setFullYear(date_var.getFullYear()+interval);
            }
            break;
        case 'MONTHLY': //月ごと
            if(bymonthday){
                if(bymonthday !== "-1"){ /***** 日付指定 *****/
                    date_var.setDate(parseInt(bymonthday));
                    while(date_var.getTime() < date_const.getTime() || date_var.getTime() < date_now.getTime()){
                        date_var.setDate(1);
                        date_var.setMonth(date_var.getMonth()+1);
                        date_var.setDate(parseInt(bymonthday));
                    }
                    if(loop !== 0){
                        date_var.setDate(1);
                        date_var.setMonth(date_var.getMonth()+1);
                        date_var.setDate(parseInt(bymonthday));
                    }
                    all_dates.push(formatDateString(date_var));
                }
                else{ /***** 月末 *****/
                    if(loop == 0){date_var.setDate(1)};
                    date_var.setMonth(date_var.getMonth() + 1);
                    date_var.setDate(0);
                    while(date_var.getTime() < date_const.getTime() || date_var.getTime() < date_now.getTime()) {
                        date_var.setDate(1);
                        date_var.setMonth(date_var.getMonth()+2);
                        date_var.setDate(0);
                    }
                    all_dates.push(formatDateString(date_var));
                    date_var.setDate(1);
                    date_var.setMonth(date_var.getMonth() + 1);
                }
            }
            else{ /***** 曜日指定 *****/
                var year = date_var.getFullYear();
                var month = date_var.getMonth() + 1;
                var weekday = { "SU" : 0, "MO" : 1, "TU" : 2, "WE" : 3, "TH" : 4, "FR" : 5, "SA" : 6 };
                bysetpos = bysetpos !== "-1" ? parseInt(bysetpos) : 5;
                var date_arr = getWeekOfDay(year, month, bysetpos, weekday[byday]);
                date_var.setDate(1);
                date_var.setFullYear(date_arr['YEAR'], date_arr['MONTH']-1, date_arr['DAY']);
                
                while(date_var.getTime() < date_const.getTime() || date_var.getTime() < date_now.getTime()){
                    date_var.setDate(1);
                    date_var.setMonth(date_var.getMonth() + 1);
                    year = date_var.getFullYear();
                    month = date_var.getMonth() + 1;
                    
                    date_arr = getWeekOfDay(year, month, bysetpos, weekday[byday]);
                    date_var.setDate(1);
                    date_var.setFullYear(date_arr['YEAR'], date_arr['MONTH']-1, date_arr['DAY']);
                }
                all_dates.push(formatDateString(date_var));
                date_var.setDate(1);
                date_var.setMonth(date_var.getMonth() + 1);
            }
            break;
        case 'WEEKLY': //週ごと
            if(byday){ //曜日指定
                var weekday = {"MO" : 0, "TU" : 1, "WE" : 2, "TH" : 3, "FR" : 4, "SA" : 5, "SU" : 6 };
                for(var day of byday){
                    if(loop == 0){
                        if(date_var.getTime() < date_now.getTime()){
                            date_var.setDate(date_var.getDate() - date_var.getDay() + 1);
                            var tmp_date_now = new Date();
                            tmp_date_now = new Date(tmp_date_now.getFullYear(), tmp_date_now.getMonth(), tmp_date_now.getDate());
                            tmp_date_now.setDate(date_now.getDate() - date_now.getDay() + 1);
                        }
                        while(tmp_date_now && (date_var.getTime() < tmp_date_now.getTime())){
                            date_var.setDate(date_var.getDate() + 7);
                        }
                    }
                    target_weekday = date_var.getDay() !== 0 ? date_var.getDay()-1 : 6;
                    date_diff = weekday[day] - target_weekday;
                    date_var.setDate(date_var.getDate() + date_diff);
                    
                    if(loop == 0){
                        if(date_var.getTime() < date_now.getTime()){
                             continue;
                        }
                    }
                    all_dates.push(formatDateString(date_var));
                }
                date_var.setDate(date_var.getDate() + (7 - target_weekday));
            }else{ //曜日指定なし
                if(date_var.getTime() >= date_now.getTime()){
                    all_dates.push(formatDateString(date_var));
                }
                date_var.setDate(date_var.getDate()+(7*interval)); 
            }
            break;
        case 'DAILY':
                if(date_var.getTime() >= date_now.getTime()){
                    all_dates.push(formatDateString(date_var));
                }
                date_var.setDate(date_var.getDate()+interval); 
            break;
        case 'HOURLY':
                if(date_var.getTime() >= date_now.getTime()){
                    all_dates.push(formatDateString(date_var));
                }
                date_var.setHours(date_var.getHours()+interval); 
            break;
        case 'MINUTELY':
                if(date_var.getTime() >= date_now.getTime()){
                    all_dates.push(formatDateString(date_var));
                }
                date_var.setMinutes(date_var.getMinutes()+interval); 
            break;
    }
    return all_dates;
}

/**
 * 日付を yyyy/MM/dd HH:mm の形式で返却
 * @param String
 * @returns String
 */
function formatDateString (date) {
    var format = 'yyyy/M/d H:m'; 
    format = format.replace(/yyyy/g, date.getFullYear());
    format = format.replace(/M/g, ('00' + (date.getMonth() + 1)).substr(-2));
    format = format.replace(/d/g, ('00' + date.getDate()).substr(-2));
    format = format.replace(/H/g, ('00' + date.getHours()).substr(-2));
    format = format.replace(/m/g, ('00' + date.getMinutes()).substr(-2));
    return format;
};

/**
 * 指定年月の第n曜日の日付を求める
 * year		int		求めたい日付の年を指定
 * month	int		求めたい日付の月を指定
 * week		int		第n週か。第1週なら1、第3週なら3、最終なら5を指定
 * day		int		求めたい曜日。0(日曜)〜6(土曜)までの数字で指定
 */
function getWeekOfDay(year, month, week, day) {
    
    // 指定した年月の最初の曜日を取得
    var date = new Date(year+"/"+month+"/1");
    var firstDay = date.getDay();

    // 求めたい曜日の第1週の日付けを計算する
    day = day - firstDay + 1;
    if(day <= 0) day += 7;

    // n週まで1週間を足す
    day += 7 * (week - 1);
    prov_result = new Date(year+"/"+month+"/"+day);
    if(week == 5 && prov_result.getMonth()+1 !== month){
        day -= 7;
        result = new Date(year+"/"+month+"/"+day);
    }else{
        result = prov_result;
    }
    var a = result.getMonth()+1;
    var b = parseInt(result.getMonth()+1);
    return {
        "YEAR" : parseInt(result.getFullYear()),
        "MONTH" : parseInt(result.getMonth()+1),
        "DAY" : parseInt(result.getDate())
    };
}
/**
 * 入力チェック
 */
function requiredCheck(){
    var required_flag = true;
    
    $('.rrule-interval').bind('keyup focus click', function() {
        required_flag = toggleInvalidTooltip($('.rrule-interval'), 1);
    });
    $('.rrule-interval').blur(function() {
        $('.rrule-calcschedule-tooltip').remove();
    });
    $('.rrule-count').bind('keyup focus click', function() {
        required_flag = toggleInvalidTooltip($('.rrule-count'), 1);
    });
    $('.rrule-count').blur(function() {
        $('.rrule-calcschedule-tooltip').remove();
    });
    $('.rrule-bymonthday').bind('keyup focus click', function() {
        required_flag = toggleInvalidTooltip($('.rrule-bymonthday'), 0, 23);
    });
    $('.rrule-bymonthday').blur(function() {
        $('.rrule-calcschedule-tooltip').remove();
    });
    $('.period-byday-minute').bind('keyup focus click', function() {
        required_flag = toggleInvalidTooltip($('.period-byday-minute'), 0, 59);
    });
    $('.period-byday-minute').blur(function() {
        $('.period-tooltip').remove();
    });
    $('.period-byhour-minute').bind('keyup focus click', function() {
        required_flag = toggleInvalidTooltip($('.period-byhour-minute'), 0, 59);
    });
    $('.period-byhour-minute').blur(function() {
        $('.period-tooltip').remove();
    });
    return required_flag;
}

/**
 * 入力値正誤,必須チェック
 * @param {type} val_arr
 * @returns {Boolean}
 */
function errorCheck(val_arr){
    var required_flag = true;
    /** 必須チェック **/
    if(val_arr['interval'] == "0"){ //間隔の入力チェック
        $('.tbl-freq').find('.option-name').find('span').addClass('rrule-required');
        required_flag = false;
    }
    if(!val_arr['count'] && !val_arr['until'] || parseInt(val_arr['count']) < 1){ //終了日時の入力チェック
        $('.tbl-until').find('.option-name').find('span').addClass('rrule-required');
        required_flag = false;
    }
    var dtstart = new Date(reverseFormatISO8601Basic(val_arr['dtstart']));
    var until = new Date(reverseFormatISO8601Basic(val_arr['until']));
    if(dtstart >  until){
        $('.tbl-until').find('.option-name').find('span').addClass('rrule-required');
        required_flag = false;
    }
    switch($('.rrule-freq').val()){
        case "MONTHLY": //月ごとの日付の入力チェック
            if($('.rrule-radio-bycustom-month:checked').val() == "0" && (parseInt(val_arr['bymonthday']) < 1 || !val_arr['bymonthday'])){
                $('.tbl-bysetpos').find('.option-name').find('span').addClass('rrule-required');
                required_flag = false;
            }
            break;
    }
    
    return required_flag;
}
/**
 * RRULEの日本語表記化
 * @param {type} rrule_arr
 * @returns {String}
 */
function rruleConversionToJapanese(rrule_arr){
    var freq = rrule_arr['freq']; //周期
    var interval = rrule_arr['interval']; //間隔
    var dtstart = rrule_arr['dtstart']; //開始日時
    var until = rrule_arr['until']; //終了日時
    var count = rrule_arr['count']; //回数
    var wkst = rrule_arr['wkst']; //週の始まり曜日
    var byday = rrule_arr['byday']; //週、月の曜日指定
    var bymonth = rrule_arr['bymonth']; //年の月指定
    var bymonthday = rrule_arr['bymonthday']; //月の日にち指定
    var bysetpos = rrule_arr['bysetpos']; //カスタム値
    
    var str = "";
    
    var freq_jp = {
        "YEARLY":"年ごと",
        "MONTHLY":"か月ごと",
        "WEEKLY":"週間ごと",
        "DAILY":"日ごと",
        "HOURLY":"時間ごと",
        "MINUTELY":"分ごと"
    };
    str += interval;
    str += freq_jp[freq];
    str += "、";
    str += reverseFormatISO8601Basic(dtstart);
    str += " ～";
    if(until){
        str += " " +reverseFormatISO8601Basic(until);
    }
    if(count){
        str += "、";
        str += count + "回";
    }
    if(freq == "YEARLY" && bymonth){
        str += "、";
        var bymonth_arr = bymonth.split(',');
        var cnt = 0;
        for(var month of bymonth_arr){
            if(cnt !== 0){
               str += ", ";
            }
            str += month + "月";
            cnt++;
        }
    }
    else if(freq == "MONTHLY"){
        str += "、";
        if(bymonthday){
            if(bymonthday !== "-1"){
                str += bymonthday + " 日";
            }else{
                str += "月末";
            }
        }else{
            var weeknum_jp = {"1": "第1", "2": "第2", "3": "第3", "4": "第4", "-1": "最終"};
            var weekday_jp = {"MO" : "月曜日", "TU" : "火曜日", "WE" : "水曜日", "TH" : "木曜日", "FR" : "金曜日", "SA" : "土曜日", "SU" : "日曜日"};
            str += weeknum_jp[bysetpos];
            str += weekday_jp[byday];
        }
    }
    else if(freq == "WEEKLY"){
        if(byday){
            str += "、";
            var weekday_jp = {"MO" : "月", "TU" : "火", "WE" : "水", "TH" : "木", "FR" : "金", "SA" : "土", "SU" : "日"};
            var byday_arr = byday.split(',');
            var cnt = 0;
            for(var day of byday_arr){
                if(cnt !== 0){
                   str += ", ";
                }
                str += weekday_jp[day];
                cnt++;
            }
        }
    }
    return str;
}

/**
 * ツールチップの出し入れ
 * @param {type} $this
 * @param {type} min
 * @returns {Boolean}
 */
function toggleInvalidTooltip($this, min, max = null){
    var title = "無効な値です。";
    var $tooltip = $([
      "<span class='rrule-calcschedule-tooltip'>",
        "<span class='rrule-calcschedule-tooltip__body'>",
          title,
        "</span>",
      "</span>"
    ].join(""));
    $tooltip.hide();
    
    // チェック条件パターン
    if(parseInt($this.val()) < min || (max !== null && parseInt($this.val()) > max) || $this.val() == ""){
        $this.addClass('rrule-calcschedule-invalid-value');
        $('.rrule-calcschedule-tooltip').remove();
        $('body').append($tooltip);

        // 要素の表示位置
        var offset = $this.offset();

        // 要素のサイズ
        var size = {
          width: $this.outerWidth(),
          height: $this.outerHeight()
        };

        // ツールチップのサイズ
        var ttSize = {
          width: $tooltip.outerWidth(),
          height: $tooltip.outerHeight()
        };

        // 要素の上に横中央で配置
        $tooltip
          .css({
            top: offset.top - ttSize.height,
            left: offset.left + size.width / 2 - ttSize.width / 2
          })
          .stop(true, false)
          .fadeIn(500);
        
        return false;
    } else {
        $this.removeClass('rrule-calcschedule-invalid-value');
        $('.rrule-calcschedule-tooltip').remove();
        return true;
    }
}

function conversionJson(rrule){
    var rrule_arr = {};
    var count = 0;
    for(var date of rrule){
        count++;
        rrule_arr[count] = date;
    }
    return JSON.stringify(rrule_arr);
}